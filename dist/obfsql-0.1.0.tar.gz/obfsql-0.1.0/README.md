# OBFSQL
Putting the bracket into SQL and vise versa
## This is a package that will covert Open Bracket Format data into SQL and export the data back to OBF.

	1. Make foreign keys to tables to connect the data together.
	2. Make larger Tournament PY 